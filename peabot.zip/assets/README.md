Place all your assets in this folder
